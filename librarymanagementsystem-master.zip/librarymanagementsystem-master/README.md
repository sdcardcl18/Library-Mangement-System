# This is a web based Library Management System app which contains 2 types of users 
  namely librarian and the student.

# Features of the student side includes
  Students can create an account and login.
  Students can see the books available in the library.
  Students can issue the books from the library.
  Students can return the issued book to the library.
  Students can search the books according to their names.
  
# Features of the Librarian side includes
  The librarian can add, update and delete the books in the library.
  The librarian can update the details of the students and can delete as well.
  The librarian can see all of the students registered in the library.
  
# Tech Stack - html | css | bootstrap | django | postgresql.
